﻿using System;
using UnityEngine;
using System.Collections;

namespace Sensors1
{
    public class Sensors : MonoBehaviour
    {        
        private int sensorChosen;
        private float sensorLength = 3f;
        private int[,] proximityMatrix;
        private static int[,] rangeMatrix;
        private static int[,] lidarMatrix;

        void Start()
        {
            
        }

        /// <summary>
        /// This is API call for other components to choose the required sensor
        /// </summary>
        /// <param name="sensorType"></param>
        /// <returns></returns>
        public String chooseSensor(int sensorType)
        {
            sensorChosen = sensorType;

            switch (sensorType)
            {

                case 1:
                    return "ProximitySensor running now";

                case 2:
                    return "Range Sensor running now";

                case 3:
                    return "LidAR Sensor running now";

                case 4:
                    return "GPSSensor running now";

                case 5:
                    return "AmbientTemperatureSensor running now";

                case 6:
                    return "LiDARSensor running now";

                default:
                    return "GyroscopeSensor running now";

            }
        }

        /// <summary>
        /// This is API call for other components to get data from the required sensor        
        /// </summary>
        /// <param name="gObj">requires rover game object</param>
        /// <returns>returns a 2d 3X3 matrix which consists of obstacles set in itreturns>
        public int[,] getSensorData(GameObject gObj)
        {            
            switch (sensorChosen)
            {

                case 1:                    
                    return getProximityMatrixData(gObj);

                case 2:
                    return getRangeMatrixData(gObj);

                case 3:
                    return getMatrixFromLiDARSensor(gObj);

                case 4:
                    return getProximityMatrixData(gObj);

                case 5:
                    return getProximityMatrixData(gObj);

                case 6:
                    return getProximityMatrixData(gObj);

                default:
                    return getProximityMatrixData(gObj);

            }
        }

        /// <summary>
        /// This function calculates the 3x3 proximity matrix by finding potential obstacles
        /// in four directions
        /// It can detect obstacles at half range of the range sensor.
        /// </summary>
        /// <param name="gObj"> requires rover game object</param>
        /// <returns>Returns a 2d 3X3 matrix which consists of obstacles set in it</returns>
        int[,] getProximityMatrixData(GameObject gObj)
        {
            sensorLength = 2f;
            // initial position for every step before checking for potential collisions
            proximityMatrix = new int[,] { { 1, 0, 1 }, { 0, 2, 0 }, { 1, 0, 1 } };

            RaycastHit hit;
            Vector3 origin = gObj.transform.position;
            
            Ray frontRay = new Ray(origin, gObj.transform.TransformDirection(Vector3.forward));
            if (Physics.Raycast(frontRay, out hit, sensorLength))
            {
                //Debug.Log("found forward obstacle" + leftRay.origin + " " + hit.point);
                Debug.Log("found front obstacle");
                Debug.DrawLine(frontRay.origin, hit.point);
                proximityMatrix[1, 0] = 1;
            }
            else
            {
                proximityMatrix[1, 0] = 0;
            }
            
            Ray rightRay = new Ray(origin, gObj.transform.TransformDirection(Vector3.right));            
            if (Physics.Raycast(rightRay, out hit, sensorLength))
            {
                Debug.Log("found right obstacle");
                Debug.DrawLine(rightRay.origin, hit.point);
                proximityMatrix[0, 1] = 1;
            }
            else
            {             
                proximityMatrix[0, 1] = 0;
            }


            Ray leftRay = new Ray(origin, gObj.transform.TransformDirection(-Vector3.right));            
            if (Physics.Raycast(leftRay, out hit, sensorLength))
            {
                Debug.Log("found left obstacle");
                Debug.DrawLine(leftRay.origin, hit.point);
                proximityMatrix[2, 1] = 1;
            }
            else
            {                
                proximityMatrix[2, 1] = 0;
            }


            Ray backRay = new Ray(origin, gObj.transform.TransformDirection(-Vector3.forward));            
            if (Physics.Raycast(backRay, out hit, sensorLength))
            {
                Debug.Log("found back obstacle");
                Debug.DrawLine(backRay.origin, hit.point);
                proximityMatrix[1, 2] = 1;
            }
            else
            {
                proximityMatrix[1, 2] = 0;
            }
            return proximityMatrix;
        }


        /// <summary>
        /// This function gets a range matrix which has a 5 X 5 dimensions
        /// It detects object at twice the range of proximity matrix       
        /// </summary>
        /// <param name="gObj">requires rover game object</param>
        /// <returns>Returns a 5X5 matrix of the surrounding of rover</returns>
        private int[,] getRangeMatrixData(GameObject gObj)
        {

            sensorLength = 4f;
            // initial position for every step before checking for potential collisions
            // 5X5 matrix is taken for this sensor
            // -1: don't know; 1: obstacle found 
            rangeMatrix = new int[,] { { -1, -1, -1, -1, -1 }, { -1, -1, -1, -1, -1 }, { -1, -1, 2, -1, -1 }, { -1, -1, -1, -1, -1 }, { -1, -1, -1, -1, -1 } };

            RaycastHit hit;
            Vector3 origin = gObj.transform.position;

            Ray rightRay = new Ray(origin, gObj.transform.TransformDirection(Vector3.right));
            if (Physics.Raycast(rightRay, out hit, sensorLength))
            {
                Debug.Log("found right obstacle");

                if (hit.distance > 2.0f)
                {
                    Debug.DrawLine(rightRay.origin, hit.point);
                    rangeMatrix[2, 4] = 1;
                }
                else
                {
                    Debug.DrawLine(rightRay.origin, hit.point, Color.red);
                    rangeMatrix[2, 3] = 1;                    
                }
            }

            Ray frontRay = new Ray(origin, gObj.transform.TransformDirection(Vector3.forward));
            if (Physics.Raycast(frontRay, out hit, sensorLength))
            {
                Debug.Log("found front obstacle");


                if (hit.distance > 2.0f)
                {
                    Debug.DrawLine(frontRay.origin, hit.point);
                    rangeMatrix[0, 2] = 1;
                }
                else
                {
                    Debug.DrawLine(frontRay.origin, hit.point, Color.red);                    
                    rangeMatrix[1, 2] = 1;
                }
            }

            Ray backRay = new Ray(origin, gObj.transform.TransformDirection(-Vector3.forward));
            if (Physics.Raycast(backRay, out hit, sensorLength))
            {
                Debug.Log("found back obstacle");


                if (hit.distance > 2.0f)
                {
                    Debug.DrawLine(backRay.origin, hit.point);
                    rangeMatrix[4, 2] = 1;
                }
                else
                {
                    Debug.DrawLine(backRay.origin, hit.point, Color.red);
                    rangeMatrix[3, 2] = 1;                    
                }
            }


            Ray leftRay = new Ray(origin, gObj.transform.TransformDirection(-Vector3.right));
            if (Physics.Raycast(leftRay, out hit, sensorLength))
            {
                Debug.Log("found left obstacle");


                if (hit.distance > 2.0f)
                {
                    Debug.DrawLine(leftRay.origin, hit.point);
                    rangeMatrix[2, 0] = 1;
                }
                else
                {
                    Debug.DrawLine(leftRay.origin, hit.point, Color.red);
                    rangeMatrix[2, 1] = 1;                    
                }
            }

            // for four 45 degrees directions 
            var rightdirection = Quaternion.AngleAxis(45, Vector3.up) * gObj.transform.forward;
            Ray frontRightRay = new Ray(origin, rightdirection);
            if (Physics.Raycast(frontRightRay, out hit, sensorLength))
            {
                Debug.Log("found frontRightRay obstacle");

                if (hit.distance > 2.0f)
                {
                    Debug.DrawLine(frontRightRay.origin, hit.point);
                    rangeMatrix[0, 4] = 1;
                }
                else
                {
                    Debug.DrawLine(frontRightRay.origin, hit.point, Color.red);
                    rangeMatrix[1, 3] = 1;                    
                }
            }

            var leftdirection = Quaternion.AngleAxis(-45, Vector3.up) * gObj.transform.forward;
            Ray frontLeftRay = new Ray(origin, leftdirection);
            if (Physics.Raycast(frontLeftRay, out hit, sensorLength))
            {
                Debug.Log("found frontLeftRay obstacle");

                if (hit.distance > 2.0f)
                {
                    Debug.DrawLine(frontLeftRay.origin, hit.point);
                    rangeMatrix[0, 0] = 1;
                }
                else
                {
                    Debug.DrawLine(frontLeftRay.origin, hit.point, Color.red);                    
                    rangeMatrix[1, 1] = 1;
                }
            }

            var backrightdirection = Quaternion.AngleAxis(45, Vector3.up) * gObj.transform.right;
            Ray backRightRay = new Ray(origin, backrightdirection);

            if (Physics.Raycast(backRightRay, out hit, sensorLength))
            {
                Debug.Log("found backRightRay obstacle");

                if (hit.distance > 2.0f)
                {
                    Debug.DrawLine(backRightRay.origin, hit.point);
                    rangeMatrix[4, 4] = 1;
                }
                else
                {
                    Debug.DrawLine(backRightRay.origin, hit.point, Color.red);
                    rangeMatrix[3, 3] = 1;                    
                }
            }

            var backleftdirection = Quaternion.AngleAxis(-45, Vector3.up) * -gObj.transform.right;
            Ray backLeftRay = new Ray(origin, backleftdirection);

            if (Physics.Raycast(backLeftRay, out hit, sensorLength))
            {
                Debug.Log("found backLeftRay obstacle");

                if (hit.distance > 2.0f)
                {
                    Debug.DrawLine(backLeftRay.origin, hit.point);
                    rangeMatrix[4, 0] = 1;
                }
                else
                {
                    Debug.DrawLine(backLeftRay.origin, hit.point, Color.red);
                    rangeMatrix[3, 1] = 1;                    
                }
            }

            return rangeMatrix;

        }


        /// <summary>
        /// This function sets lidar matrix which has a 5 X 5 dimensions
        /// It detects object only in front of it. It detects the distance 
        /// from the potential collision to rover        
        /// </summary>
        /// <param name="gObj">requires rover game object</param>
        /// <returns>Returns a 5X5 matrix of the surrounding of rover</returns>
        private int[,] getMatrixFromLiDARSensor(GameObject gObj)
        {
            // initial position for every step before checking for potential collisions
            // 5X5 matrix is taken for this sensor
            // -1 : don't know; setting distance of collision to object in range of (1f-2f)
            lidarMatrix = new int[,] { { -1, -1, -1, -1, -1 }, { -1, -1, -1, -1, -1 }, { -1, -1, 2, -1, -1 }, { -1, -1, -1, -1, -1 }, { -1, -1, -1, -1, -1 } };

            RaycastHit hit;
            Vector3 origin = gObj.transform.position;


            Ray frontRay = new Ray(origin, gObj.transform.TransformDirection(Vector3.forward));
            if (Physics.Raycast(frontRay, out hit, sensorLength))
            {
                Debug.Log("found front obstacle");


                if (hit.distance > 2.0f)
                {
                    Debug.DrawLine(frontRay.origin, hit.point, Color.green);
                    lidarMatrix[0, 2] = (int)hit.distance;
                }
                else
                {
                    Debug.DrawLine(frontRay.origin, hit.point, Color.red);
                    lidarMatrix[1, 2] = (int)hit.distance;
                }
            }


            // for angled degrees directions 
            var right_45_direction = Quaternion.AngleAxis(45, Vector3.up) * gObj.transform.forward;
            Ray frontRight_45_Ray = new Ray(origin, right_45_direction);
            if (Physics.Raycast(frontRight_45_Ray, out hit, sensorLength))
            {
                Debug.Log("found frontRightRay obstacle at 45 deg");

                if (hit.distance > 2.0f)
                {
                    Debug.DrawLine(frontRight_45_Ray.origin, hit.point, Color.green);
                    lidarMatrix[0, 4] = (int)hit.distance;
                }
                else
                {
                    Debug.DrawLine(frontRight_45_Ray.origin, hit.point, Color.red);
                    lidarMatrix[1, 3] = (int)hit.distance;
                }
            }

            var right_25_direction = Quaternion.AngleAxis(25, Vector3.up) * gObj.transform.forward;
            Ray frontRight_25_Ray = new Ray(origin, right_25_direction);
            if (Physics.Raycast(frontRight_25_Ray, out hit, sensorLength))
            {
                Debug.Log("found frontRightRay obstacle at 25 deg");

                if (hit.distance > 2.0f)
                {
                    Debug.DrawLine(frontRight_25_Ray.origin, hit.point, Color.green);
                    lidarMatrix[0, 4] = (int)hit.distance;
                }
                else
                {
                    Debug.DrawLine(frontRight_25_Ray.origin, hit.point, Color.red);
                    lidarMatrix[1, 3] = (int)hit.distance;
                }
            }

            var left_45_direction = Quaternion.AngleAxis(-45, Vector3.up) * gObj.transform.forward;
            Ray frontLeft_45_Ray = new Ray(origin, left_45_direction);
            if (Physics.Raycast(frontLeft_45_Ray, out hit, sensorLength))
            {
                Debug.Log("found frontLeftRay obstacle at 45 deg");

                if (hit.distance > 2.0f)
                {
                    Debug.DrawLine(frontLeft_45_Ray.origin, hit.point, Color.green);
                    lidarMatrix[0, 0] = (int)hit.distance;
                }
                else
                {
                    Debug.DrawLine(frontLeft_45_Ray.origin, hit.point, Color.red);
                    lidarMatrix[1, 1] = (int)hit.distance;
                }
            }

            var left_25_direction = Quaternion.AngleAxis(-25, Vector3.up) * gObj.transform.forward;
            Ray frontLeft_25_Ray = new Ray(origin, left_25_direction);
            if (Physics.Raycast(frontLeft_25_Ray, out hit, sensorLength))
            {
                Debug.Log("found frontLeftRay obstacle at 25 deg");

                if (hit.distance > 2.0f)
                {
                    Debug.DrawLine(frontLeft_25_Ray.origin, hit.point, Color.green);
                    lidarMatrix[0, 0] = (int)hit.distance;
                }
                else
                {
                    Debug.DrawLine(frontLeft_25_Ray.origin, hit.point, Color.red);
                    lidarMatrix[1, 1] = (int)hit.distance;
                }
            }

            return lidarMatrix;
        }

    }
}
